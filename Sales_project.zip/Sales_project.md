# 📊 Proiect: **Analiza Vânzărilor - EDA**

Acest notebook conține o analiză exploratorie a unui set de date de vânzări.  
Vom parcurge următorii pași:

1. **Încărcarea și explorarea datasetului**
2. **Curățarea datelor**
3. **Analiza cantitativă și vizualizări**
4. **Concluzii finale**

> 🔎 Scop: Identificarea produselor și regiunilor cu cele mai mari venituri și analiza trendurilor de vânzări.


```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
```

## 🧰 1. Importul bibliotecilor

Importăm bibliotecile necesare pentru citirea, manipularea și vizualizarea datelor.


```python
# Citire fișier CSV
df = pd.read_csv('sales_data.csv')

# Primele rânduri
print(df.head())
```

       Order ID        Date  Product     Category Region  Units Sold  Unit Price  \
    0      1001  2024-01-01  Monitor  Accessories   East          33      536.71   
    1      1002  2024-01-02    Mouse  Accessories  South          33      296.04   
    2      1003  2024-01-03   Tablet  Accessories   East          43      987.93   
    3      1004  2024-01-04    Mouse  Electronics   East          37      612.99   
    4      1005  2024-01-05    Mouse  Electronics  South          12      382.62   
    
        Revenue  
    0  17711.43  
    1   9769.32  
    2  42480.99  
    3  22680.63  
    4   4591.44  
    

## 📥 2. Încărcarea datelor

Citim fișierul CSV `sales_data.csv` și aruncăm o privire asupra primelor rânduri.


```python
# Info despre date
print(df.info())

# Conversie coloana 'Date'
df['Date'] = pd.to_datetime(df['Date'])
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 200 entries, 0 to 199
    Data columns (total 8 columns):
     #   Column      Non-Null Count  Dtype  
    ---  ------      --------------  -----  
     0   Order ID    200 non-null    int64  
     1   Date        200 non-null    object 
     2   Product     200 non-null    object 
     3   Category    200 non-null    object 
     4   Region      200 non-null    object 
     5   Units Sold  200 non-null    int64  
     6   Unit Price  200 non-null    float64
     7   Revenue     200 non-null    float64
    dtypes: float64(2), int64(2), object(4)
    memory usage: 12.6+ KB
    None
    

## 🔍 3. Explorare inițială

Examinăm informațiile despre tipurile de date, valorile lipsă și statistici descriptive.


```python
#  1. Verificare duplicate
duplicatee = df.duplicated().sum()
print(f"Număr de rânduri duplicate: {duplicatee}")

#  2. Verificare valori lipsă
print("\nValori lipsă pe coloană:")
print(df.isnull().sum())

#  3. Statistici descriptive pentru coloane numerice
print("\nStatistici descriptive:")
print(df.describe())

#  4. Cele mai vândute produse (după unități)
top_products_units = df.groupby('Product')['Units Sold'].sum().sort_values(ascending=False)
print("\nTop produse după unități vândute:")
print(top_products_units)

#  5. Venit total pe regiune
revenit_regiune = df.groupby('Region')['Revenue'].sum().sort_values(ascending=False)
print("\nVenit total pe regiune:")
print(revenit_regiune)
```

    Număr de rânduri duplicate: 0
    
    Valori lipsă pe coloană:
    Order ID      0
    Date          0
    Product       0
    Category      0
    Region        0
    Units Sold    0
    Unit Price    0
    Revenue       0
    dtype: int64
    
    Statistici descriptive:
              Order ID                 Date  Units Sold   Unit Price       Revenue
    count   200.000000                  200  200.000000   200.000000    200.000000
    mean   1100.500000  2024-04-09 12:00:00   25.635000   766.268400  19294.643350
    min    1001.000000  2024-01-01 00:00:00    1.000000    53.760000    564.900000
    25%    1050.750000  2024-02-19 18:00:00   13.000000   433.440000   5614.805000
    50%    1100.500000  2024-04-09 12:00:00   25.000000   782.180000  15600.105000
    75%    1150.250000  2024-05-29 06:00:00   37.000000  1107.057500  28817.942500
    max    1200.000000  2024-07-18 00:00:00   49.000000  1496.020000  65033.420000
    std      57.879185                  NaN   13.941434   410.590983  15524.411331
    
    Top produse după unități vândute:
    Product
    Monitor       1219
    Laptop        1076
    Tablet         993
    Smartphone     959
    Mouse          880
    Name: Units Sold, dtype: int64
    
    Venit total pe regiune:
    Region
    South    1123830.57
    West      994610.55
    East      915253.36
    North     825234.19
    Name: Revenue, dtype: float64
    

##  Explorare 

În această etapă analizăm structura și calitatea datelor:
- Verificăm dacă există duplicate
- Căutăm valori lipsă
- Calculăm statistici descriptive (medie, minim, maxim, etc.)
- Identificăm cele mai vândute produse și regiunile cele mai profitabile


```python
import seaborn as sns
import matplotlib.pyplot as plt

# Top produse după unități
top_products_units = df.groupby('Product')['Units Sold'].sum().sort_values(ascending=False).reset_index()

plt.figure(figsize=(8, 5))
sns.barplot(data=top_products_units, x='Units Sold', y='Product',hue='Product', palette='viridis',legend=False)
plt.title(' Top Produse după Număr de Unități Vândute')
plt.xlabel('Unități Vândute')
plt.ylabel('Produs')
plt.tight_layout()
plt.show()
```


    
![png](output_9_0.png)
    



```python
plt.figure(figsize=(6, 4))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap='coolwarm', fmt=".2f")
plt.title(' Corelații între variabile numerice')
plt.tight_layout()
plt.show()
```


    
![png](output_10_0.png)
    



```python
plt.figure(figsize=(8, 5))
sns.boxplot(data=df, x='Product', y='Unit Price', hue='Product', palette='Set2',legend=False)
plt.title('Distribuția prețurilor pe produs')
plt.xlabel('Produs')
plt.ylabel('Preț unitar')
plt.tight_layout()
plt.show()
```


    
![png](output_11_0.png)
    


## 📊 4. Vizualizări adiționale

Creăm câteva grafice pentru a evidenția tipare în date:

- **Bar chart**: Cele mai vândute produse (după număr de unități)
- **Heatmap**: Corelații între variabile numerice (ex: Units Sold vs Revenue)
- **Boxplot**: Distribuția prețurilor pe produs, pentru a observa variațiile sau outlierii


```python
total_revenue = df['Revenue'].sum()
total_orders = df['Order ID'].nunique()
avg_order_value = total_revenue / total_orders

print(f" Venit total: {total_revenue:,.2f}")
print(f" Număr comenzi: {total_orders}")
print(f" Valoare medie comandă: {avg_order_value:,.2f}")
```

     Venit total: 3,858,928.67
     Număr comenzi: 200
     Valoare medie comandă: 19,294.64
    


```python
df['Weekday'] = df['Date'].dt.day_name()
sales_by_day = df.groupby('Weekday')['Revenue'].sum().sort_values(ascending=False)

sns.barplot(x=sales_by_day.values, y=sales_by_day.index)
plt.title(" Venit total pe zi a săptămânii")
plt.xlabel("Venit")
plt.ylabel("Zi")
plt.tight_layout()
plt.show()
```


    
![png](output_14_0.png)
    



```python
pivot = df.pivot_table(index='Region', columns='Product', values='Revenue', aggfunc='sum', fill_value=0)
display(pivot)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Product</th>
      <th>Laptop</th>
      <th>Monitor</th>
      <th>Mouse</th>
      <th>Smartphone</th>
      <th>Tablet</th>
    </tr>
    <tr>
      <th>Region</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>East</th>
      <td>89664.88</td>
      <td>114738.68</td>
      <td>253934.90</td>
      <td>175782.73</td>
      <td>281132.17</td>
    </tr>
    <tr>
      <th>North</th>
      <td>154197.01</td>
      <td>214003.46</td>
      <td>136754.25</td>
      <td>185953.08</td>
      <td>134326.39</td>
    </tr>
    <tr>
      <th>South</th>
      <td>263045.62</td>
      <td>377209.52</td>
      <td>169575.75</td>
      <td>192365.50</td>
      <td>121634.18</td>
    </tr>
    <tr>
      <th>West</th>
      <td>249171.86</td>
      <td>221544.41</td>
      <td>193750.78</td>
      <td>150103.81</td>
      <td>180039.69</td>
    </tr>
  </tbody>
</table>
</div>


## ✅ Concluzii

- Cele mai profitabile produse sunt: **Monitor**, **Laptop**
- Cea mai performantă regiune este: **South**
- Majoritatea comenzilor au venit în: **[ziua cu cele mai mari vânzări]**
- Valoarea medie a unei comenzi este de aproximativ **XYZ lei**

### 📌 Recomandări:
- Creșterea stocurilor pentru produsele de top
- Lansarea de campanii promoționale în zilele de vârf
- Optimizarea prețurilor pentru produsele cu variație mare (boxplot)




```python

```
